export const apiUrl = "http://localhost:8000/api/players/";

export const playStatus = {
	playing: "playing",
	notPlaying: "not playing",
	undecided: "undecided"
};
